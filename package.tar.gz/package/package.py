import os
import tarfile
from glob import iglob

def rglob(file_pattern, walk_root='.'):
    for root, dirs, files in os.walk(walk_root):
        for item in iglob(os.path.join(root, file_pattern)):
            yield item

def create_install(file_name):
    str = file_name[2:-3] + '.py:${plugin_dir}'
    install_file_path = file_name[2:-3] + '/install'
    file = open(install_file_path, 'w')
    file.write(str)
    file.close()

def setup_dir(file_name):
    if not os.path.exists(file_name[2:-3]):
        os.mkdir(file_name[2:-3])
    os.rename(file_name, file_name[2:-3] + '/' + file_name[2:])
    
def package_dir(name):
    tf = tarfile.open(name+'.tar.gz', 'w:gz')
    tf.add(name)
    tf.close()
    
def main():
    for file in rglob('*.py'):
        setup_dir(file)
        create_install(file)
        package_dir(file[2:-3])
        print file[2: -3]
        

main()
